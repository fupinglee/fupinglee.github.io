?><?php @eval("//Encode by  phpjiami.com,Free user."); ?><?php
error_reporting(0);
if (empty($_GET['id'])) {
    show_source(__FILE__);
    die();
}else{
$a = "www.OPENCTF.com";
$id = $_GET['id'];
@parse_str($id);
var_dump($a[0]);
if ($a[0] != 'QNKCDZO' && md5($a[0]) == md5('QNKCDZO')) {
    echo $flag;
}else{
exit('��ʵ�ܼ���ʵ�����ѣ�');
}
}


?><?php 